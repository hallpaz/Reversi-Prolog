AMPED FOR EVIL is a *FREE* font inspired by the Wollongong, Australia Punk/Hardcore band DYSTEMPA.  The font consists of crusty/torn capital letters with disintegrating bordered fill, basic punctuation and two dingbats (* and # keys).  All lowercase keys have been mapped to the corresponding capital letters.  

Due to the crusty/torn design of the letters and disintegrating fill, AMPED FOR EVIL looks best when printed athigh-quality printers (laser or otherwise) at 24-pt or higher.  On-screen, Adobe Photoshop and Illustrator display the font cleanest.  For use in Microsoft Word, turn off "smart quotes" in the "Options" menu to ensure single and double-quote characters can be displayed.

This font is completely *FREE* and distributed as such.

Questions and comments can be directed to me at ryan_splint@yahoo.com

Rock N Roll
- Ryan